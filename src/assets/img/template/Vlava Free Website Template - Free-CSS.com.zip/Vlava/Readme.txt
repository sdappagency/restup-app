Thanks for downloading this theme!

Theme Name: Vlava
Theme URL: https://bootstrapmade.com/vlava-free-bootstrap-one-page-template/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com
